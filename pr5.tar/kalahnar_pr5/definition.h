#ifndef __DEF__
#define __DEF__
#include <stdio.h>
#pragma pack(1)
//creating struct of an animal
struct animal {
    short int id;
    char name[20];
    char species[35];
    char size;
    short int age;
};
//declaring functions in the header file
void function1(FILE *file);
void function2(FILE *file);
void function3(FILE *file, int recNumber);
void function4(FILE *file, int recNumber);
void function5(FILE *file, int recNumber);
#endif
