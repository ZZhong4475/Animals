/*
 * Author: Luka Gajic kalahnar@uw.edu
 * Project: pr5.c
 * Version: 1.0
 * Worked on: Ubuntu 16.04 LTS Desktop 32-bit
*/
#include <stdio.h>
#include "definition.h"
int main()
{
	//open file
	FILE *file = fopen("animals.dat","r+");
	int choice, recNumber;
	while(1)
	{
		printf("Enter your choice. (0-5) : ");
		scanf("%d",&choice);
		switch(choice)
		{
			case 0://choice 0
				return 0;
				break;

			case 1://choice 1
				function1(file);
				break;

			case 2://choice 2
				function2(file);
				break;

			case 3://choice 3
				printf("Enter which record do you want to see : ");
				scanf("%d",&recNumber);
				function3(file, recNumber);
				break;

			case 4: //choice 4
				printf("Enter which record do you want to update : ");
				scanf("%d",&recNumber);
				function4(file, recNumber);
				break;

			case 5: //choice 5
				printf("Enter which record do you want to update : ");
				scanf("%d",&recNumber);
				function5(file, recNumber);

				break;

			default:
				printf("Please enter a valid choice (0-5)\n");
		}
	}
	return 0;
}

