#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include "definition.h"
#include <unistd.h>
#include <sys/types.h>

/* function for 1st case */
void function1(FILE *file)
{
	unsigned char buffer;
	int count = 0;
	fseek(file, 0, SEEK_SET);
	while(fread(&buffer, 1, 1, file) > 0)
	{
		if(buffer >= 32 && buffer <= 127)
			count += printf("%c",buffer);
		else
			count += printf(" ");

		if(count == 80)
		{
			count = 0;
			printf("\n");	
		}
	}
	printf("\n");
}

/* function for second case */
void function2(FILE *file)
{
	int buffer;
	int count = 0;
	fseek(file, 0, SEEK_SET);
	while(fread(&buffer, 4, 1, file) > 0)
	{
		count += printf("%d ",buffer);

		if(count >= 72)
		{
			count = 0;
			printf("\n");
		}
	}
	printf("\n");

}

/* function for 3rd case */
void function3(FILE *fileptr, int recNumber)
{
	struct animal a;
	fseek(fileptr, (recNumber - 1)*sizeof(struct animal) , SEEK_SET);
	/* parse the file and get the record */
	if(fread(&a, sizeof(struct animal), 1, fileptr) > 0)
	{
		if(a.id == recNumber)
		{
			if(strcmp(a.name, "unknown") != 0)
			{
				printf("%hd %s %s %c %hd\n",a.id,a.name, a.species, a.size, a.age);
				return;
			}
		}
	}
	printf("Error. Record not found\n");

}

/*function for 4th case */
void function4(FILE *file, int recNumber)
{
	fseek(file, (recNumber - 1)*sizeof(struct animal) , SEEK_SET);
	struct animal a;
	/* parse the file and get the record */
	if(fread(&a, sizeof(struct animal), 1, file) > 0)
	{
		if(a.id == recNumber && strcmp(a.name, "unknown") != 0)
		{
			int ch;
			printf("Enter 1 if you want to update name, enter 2 to update species, enter 3 to update size, and enter 4 to update age : ");
			scanf("%d",&ch);
			if(ch == 1)
			{
				printf("Enter name : ");
				fflush(stdin);
				getchar();
				fgets(a.name, 20, stdin);
				a.name[strlen(a.name)-1] = '\0';

			}
			else if(ch == 2)
			{
				printf("Enter species : ");
				fflush(stdin);
				getchar();
				fgets(a.species, 34, stdin);
				a.species[strlen(a.species)-1] = '\0';
			}
			else if(ch == 3)
			{
				char sz;
				printf("Enter size : ");
				scanf("%c",&(sz));
				a.size = sz;
			}
			else if(ch == 4)
			{
				printf("Enter age ");
				short age;
				scanf("%hd",&age);
				a.age = age;

			}
			else
			{
				printf("invalid choice\n");
				return;
			}
			fseek(file, (recNumber - 1)*sizeof(struct animal), SEEK_SET);
			fwrite(&a, sizeof(a), 1, file);
			printf("Record is updated\n");
			return;
		}
		else
		{
			printf("Error. Invalid record id\n");
			return;
		}
	}
	printf("Error. Invalid record id\n");

}

/* function for 5th case */
void function5(FILE *file, int recNumber)
{
	fseek(file, (recNumber - 1)*sizeof(struct animal) , SEEK_SET);
	struct animal a;
	/* parse the file and get the record */
	if(fread(&a, sizeof(struct animal), 1, file) > 0 )
	{
		if(a.id == recNumber && strcmp(a.name, "unknown") != 0)
		{
			/* find the last record and replace the current record with it */
			struct animal temp;
			while(fread(&temp, sizeof(struct animal), 1, file) > 0 )
			{
				strncpy(a.name, temp.name, 20);
				strncpy(a.species, temp.species, 35);
				a.age = temp.age;
				a.size = temp.size;
			}
			fseek(file, (recNumber - 1)*sizeof(struct animal) , SEEK_SET);
			fwrite(&a, sizeof(a), 1, file);			
			truncate("animal.dat",sizeof(struct animal));
			printf("Data copied and file truncated\n");
			return;
		}
		else
		{
			printf("Error. Invalid value entered\n");
			return;
		}
	}
	printf("Error. Record not found\n");

}
